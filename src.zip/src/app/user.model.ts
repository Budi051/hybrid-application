export class UserModel { 
  constructor(public iduser: string,
  public password: string) {}
}